<?php $__env->startSection('title'); ?>
##parent-placeholder-3c6de1b7dd91465d437ef415f94f36afc1fbc8a8##
<?php echo e($data['title']); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>


<div class="hero-wrap hero-bread" style="background-image: url('img/banner/bn_2.png'); margin-top: 70px;">
      <div class="container">
        <div class="row no-gutters slider-text align-items-center justify-content-center">
          <div class="col-md-9 ftco-animate text-center">
            <p class="breadcrumbs"><span class="mr-2"><a href="<?php echo e(route('trangchu')); ?>">Trang chủ</a></span></p>
            <h1 class="mb-0 bread">Tài khoản - Đổi mật khẩu</h1>
          </div>
        </div>
      </div>
    </div>


<!-- content-->
<section class="product_list best_seller">
	<div class="container">
		<div class="content">
            <div class="animated fadeIn">
                <div class="row">
                   <div class="col-md-2">
                   </div>
                   <div class="col-md-8">
                       <div class="card-body card-block" >
                        <form action="<?php echo e(route('doimatkhau',Session('login'))); ?>" method="post" class="form-horizontal" enctype="multidata/form-data">
                        <?php echo csrf_field(); ?>
                        <div class="row form-group">
                          <div class="col col-md-12" style="text-align: center;"><label for="exampleInputName2" class="pr-1  form-control-label"><h2>Đổi mật khẩu</h2></label>
                          </div>
                          <?php if(Session::has('success')): ?>
                            <div class="col col-md-12 text-center"><label for="exampleInputName2" class="pr-1  form-control-label"><h4 style="color: green;"><?php echo e(Session('success')); ?></h4>
                                </label>
                            </div>
                            <?php endif; ?>
                            <?php if(Session::has('false')): ?>
                            <div class="col col-md-12 text-center"><label for="exampleInputName2" class="pr-1  form-control-label"><h4 style="color: red;"><?php echo e(Session('false')); ?></h4>
                                </label>
                            </div>
                            <?php endif; ?>
                      </div>
                      <hr/>
                      <div class="row form-group">
                          <div class="col col-md-3"><label for="exampleInputName2" class="pr-1  form-control-label"><b>Mật khẩu cũ</b></label>
                          </div>
                          <div class="col-12 col-md-9"><input name="mkcu" type="password"  value="" required="" class="form-control"><span class="help-block"></span>


                            </div>
                      </div>
                      <hr/>
                      <div class="row form-group">
                          <div class="col col-md-3"><label for="exampleInputName2" class="pr-1  form-control-label"><b>Mật khẩu mới</b></label>
                          </div>
                          <div class="col-12 col-md-9"><input type="password" name="mkmoi" value="" required="" placeholder="( ít nhất 6 ký tự )" class="form-control <?php $__errorArgs = ['mkmoi'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"><span class="help-block"></span>
                            <?php $__errorArgs = ['mkmoi'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                          </div>
                      </div>
                      <hr/>
                      <div class="row form-group">
                          <div class="col col-md-3"><label for="exampleInputName2" class="pr-1  form-control-label"><b>Nhập lại mật khẩu mới</b></label>
                          </div>
                          <div class="col-12 col-md-9"><input type="password" name="cfmkmoi" value="" required="" class="form-control <?php $__errorArgs = ['cfmkmoi'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"><span class="help-block"></span>
                            <?php $__errorArgs = ['cfmkmoi'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                          </div>
                      </div>
                      <hr/>


                      <div class="form-actions form-group text-center"><button type="submit" class="btn btn-success btn-default" name="sub" value="admin">Đổi mật khẩu</button></div>
                    </form>
                </div>

              </div>
              <div class="col-md-2">
              </div>
          </div>
      </div><!-- .animated -->
  </div><!-- .content -->
</div>
</section>
<!-- het phan thong tin tai khoan-->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('user/layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\chiasedodung\resources\views/user/doimatkhau.blade.php ENDPATH**/ ?>