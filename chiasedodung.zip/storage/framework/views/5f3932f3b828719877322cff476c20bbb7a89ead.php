<?php $__env->startSection('title'); ?>
##parent-placeholder-3c6de1b7dd91465d437ef415f94f36afc1fbc8a8##
<?php echo e($data['title']); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="content">
    <div class="animated fadeIn">
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">
                        <strong class="card-title"><i>Danh sách đồ cần duyệt</i></strong>
                    </div>
                </div>
                <div class="col-lg-12">
                    <div class="row align-items-center latest_product_inner">
                        <?php $__currentLoopData = $data['items']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="col-lg-3 col-sm-6">
                                <div class="align-content-center">
                                    <img class="img-fluid" style="width: 235px; height:200px" src="imagesitems/<?php echo e($item->image); ?>" alt="">

                                    <div class="single_product_text text-center" >
                                        <h4><?php echo e($item->name); ?></h4>
                                        <button style="background: #CC33FF;"><a href="<?php echo e(route('chitiet',$item->id)); ?>" ><i class="fa fa-eye"  style="color: white;"></i></a></button>
                                        <button style="background: green"><a href="<?php echo e(route('duyet',$item->id)); ?>" ><i class="fa fa-check"  style="color: white;"></i></a></button>
                                        <button style="background: red"><a href="<?php echo e(route('huy',$item->id)); ?>" ><i class="fa fa-times"  style="color: white;"></i></a></button>
                                        <hr>
                                    </div>
                                </div>
                             </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>

                <div class="col-lg-12">
                   <div class="">
                      <nav aria-label="Page navigation example">
                         <ul class="pagination justify-content-center">
                            <?php echo e($data['items']->links("pagination::bootstrap-4")); ?>

                         </ul>
                      </nav>
                   </div>
                </div>

            </div>
        </div><!-- .animated -->
    </div><!-- .content -->
</div>

<div class="clearfix"></div>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('admin/layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\chiasedodung\resources\views/admin/duyetdodung.blade.php ENDPATH**/ ?>