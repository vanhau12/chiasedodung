<?php $__env->startSection('title'); ?>
##parent-placeholder-3c6de1b7dd91465d437ef415f94f36afc1fbc8a8##
<?php echo e($data['title']); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="content">
    <div class="animated fadeIn">
        <div class="row">
            <!-- phan nut them -->
            <div class="col-md-12">
                <form action="<?php echo e(route('themdanhmuc')); ?>" method="post" enctype="multidata/form-data">
                    <?php echo csrf_field(); ?>
                    <?php if (Session::has('success')): ?>
                        <div class="col col-md-12"><label for="exampleInputName2" class="pr-1  form-control-label"><h4 style="color: green;"><?php echo e(Session('success')); ?></h4></label>
                        </div>
                   <?php endif ?>
                    <div class="row form-group">
                        <div class="col-md-2">
                            <label><b>Tên danh mục</b></label>
                        </div>
                        <div class="col-md-6">
                            <input type="text" name="name" required class="form-control <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                                <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="form-actions form-group text-center col-md-4"><button type="submit" class="btn btn-success btn-default" name="submit">Thêm</button></div>
                    </div>

                </form>

            </div>
            <div class="col-md-12 text-center">

            </div>
            <!-- het phan nut them -->
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">
                        <strong class="card-title"><i>Danh sách danh mục</i></strong>
                    </div>
                    <div class="card-body">
                        <table id="bootstrap-data-table" class="table table-striped table-bordered">
                            <thead class="text-center">
                                <tr>
                                    <th>ID</th>
                                    <th>Tên Danh Mục</th>
                                    <th></th>
                                </tr>
                            </thead>
                            <tbody class="text-center">
                                <?php foreach ($data['types'] as $value): ?>
                                <tr>
                                    <td><?php echo e($value->id); ?></td>
                                    <td><?php echo e($value->name); ?></td>
                                    <td>
                                        <button style="background: red"><a id="btn" href=<?php echo e(route('xoadanhmuc',$value->id)); ?> ><i class="fa fa-times"  style="color: white;"></i></a></button>
                                    </td>
                                </tr>

                                <!-- <script>
                                    function myfun(id) {
                                      var r = confirm("Xác nhận xóa!");
                                      function handler() { alert('hello'); }
                                      if (r == true) {
                                        $('#btn').onclick();
                                      }
                                    }
                                </script> -->
                                <?php endforeach ?>
                            </tbody>
                        </table>

                    </div>
                </div>
            </div>
        </div>
    </div><!-- .animated -->
</div><!-- .content -->


<div class="clearfix"></div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin/layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\chiasedodung\resources\views/admin/qldanhmuc.blade.php ENDPATH**/ ?>