<?php $__env->startSection('title'); ?>
##parent-placeholder-3c6de1b7dd91465d437ef415f94f36afc1fbc8a8##
<?php echo e($data['title']); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>



<div class="hero-wrap hero-bread" style="background-image: url('img/banner/bn_1.jpg'); margin-top: 70px;">
      <div class="container">
        <div class="row no-gutters slider-text align-items-center justify-content-center">
          <div class="col-md-9 ftco-animate text-center">
            <p class="breadcrumbs"><span class="mr-2"><a href="<?php echo e(route('trangchu')); ?>">Trang chủ</a></span></p>
            <h1 class="mb-0 bread">Đồ dùng</h1>
          </div>
        </div>
      </div>
    </div>



<section class="ftco-section ftco-degree-bg">
   <div class="container">
     <div class="row">
      <div class="col-lg-8 ftco-animate">
         <div class="row">
            <div class="col-md-12 single_product_menu">
               <p><span style="color: #ff3368; font-weight: bold;"><?php echo e($data['tongso']); ?></span> Đồ Dùng Chia Sẻ Được Tìm Thấy</p>
            </div>
            <?php $__currentLoopData = $data['items']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
               <div class="col-md-12 d-flex ftco-animate">
                  <div class="blog-entry align-self-stretch d-md-flex">
                      <a href="<?php echo e(route('chitiet',$item->id)); ?>" class="block-20 img-fluid" style="background-image: url('imagesitems/<?php echo e($item->image); ?>');">
                      </a>
                     <div class="text d-block pl-md-4">
                        <div class="meta mb-3">
                          <div><span class="icon-calendar"></span> <?php echo e(date('M d, Y g:i a',$item->createdate)); ?></div>
                          <div><span class="ion-md-eye"></span> <?php echo e($item->view); ?></div>
                          <div><span class="ion-md-heart"></span> <?php echo e($item->liked); ?></div>
                        </div>
                          <h3 class="heading"><a href="<?php echo e(route('chitiet',$item->id)); ?>"><?php echo e($item->name); ?></a></h3>
                          <p><?php echo e($item->request); ?></p>
                          <p><?php echo e($item->introduce); ?></p>
                          <p><a href="<?php echo e(route('chitiet',$item->id)); ?>" class="btn btn-primary py-2 px-3">Chi tiết</a></p>
                     </div>
                  </div>
               </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
             <div class="col-lg-12">
               <div class="">
                  <nav aria-label="Page navigation example">
                     <ul class="pagination justify-content-center">
                        <?php echo e($data['items']->links("pagination::bootstrap-4")); ?>

                     </ul>
                  </nav>
               </div>
            </div>

      </div> <!-- .col-md-8 -->
      
      <div class="col-lg-4 sidebar ftco-animate">
         <div class="sidebar-box">
           <form action="#" class="search-form">
             <div class="form-group">
               <span class="icon ion-ios-search"></span>
               <input type="text" class="form-control" placeholder="Search...">
            </div>
         </form>
      </div>
      
      <div class="sidebar-box ftco-animate">
         <h3 class="heading" style="color: #FF9900; font-weight: bold;">Danh mục</h3>
         <ul class="categories">
            <?php foreach ($data['types'] as $value): ?>
               <li>
                 <a href="<?php echo e(route('danhmuc',$value->id)); ?>" style="color: #0066CC;"><?php echo e($value->name); ?></a>
                 <!-- <span>(250)</span> -->
               </li>
            <?php endforeach ?>
         </ul>
      </div>

      

      <div class="sidebar-box ftco-animate">
        <h3 class="heading">Liên kết</h3>
        <div class="tagcloud">
          <a href="#" class="tag-cloud-link">gia đình</a>
          <a href="#" class="tag-cloud-link">học tập</a>
          <a href="#" class="tag-cloud-link">chia sẻ</a>
          <a href="#" class="tag-cloud-link">đồ dùng</a>
          <a href="#" class="tag-cloud-link">quan tâm</a>
          <a href="#" class="tag-cloud-link">tình cảm</a>
       </div>
      </div>

      <div class="sidebar-box ftco-animate">
        <h3 class="heading">Danh ngôn</h3>
        <p>Hôm nay có thể là một ngày đầy hạnh phúc đối với bạn - và đối với những người khác - nếu bạn dành thời gian để nở nụ cười cho ai đó ... để thể hiện một lời nói tử tế ... để giúp đỡ một người cần giúp đỡ ... để viết một lời ơn ... để dành một lời khích lệ cho một người đang cố gắng vượt qua khó khăn ... để chia sẻ một phần tài sản vật chất của bạn với người khác (Wiliam Arthur Ward)</p>
      </div>
      </div>

      </div>
   </div>
</section> <!-- .section -->


<?php $__env->stopSection(); ?>



<?php echo $__env->make('user/layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\chiasedodung\resources\views/user/dodung.blade.php ENDPATH**/ ?>