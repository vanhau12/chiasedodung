<?php $__env->startSection('title'); ?>
##parent-placeholder-3c6de1b7dd91465d437ef415f94f36afc1fbc8a8##
<?php echo e($data['title']); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="content">
	<div class="animated fadeIn">
		<div class="row">
			<!-- phan nut them -->
			<div class="col-md-4">
				<div class="card" style="background: #6699FF">
					<div class="btn">
						<a href="<?php echo e(route('getthemtv')); ?>" style="color: white"><b>Thêm thành viên</b></a>
					</div>
				</div>
			</div>
			<!-- het phan nut them -->
			<div class="card">
				<div class="card-header">
					<strong class="card-title"><i>Danh sách thành viên</i></strong>
				</div>
				<div class="card-body">
					<table id="bootstrap-data-table" class="table table-striped table-bordered">
						<thead>
							<tr>
								<th>ID</th>
								<th>Tên</th>
								<th>Email</th>
								<th>Mật khẩu</th>
								<th>Số điện thoại</th>
								<th>Quyền</th>
								<th></th>
							</tr>
						</thead>
						<tbody>
							<?php foreach ($data['user'] as $value): ?>
							<tr>
								<td><?php echo e($value->id); ?></td>
								<td><?php echo e($value->name); ?></td>
								<td><?php echo e($value->email); ?></td>
								<td><?php echo e($value->password); ?></td>
								<td><?php echo e($value->phone); ?></td>
								<td><?php switch ($value->permission) {
									case '0':
									echo 'Khách hàng';
									break;
									case '1':
									echo 'Quản lý';
									break;
									default:
									echo '';
									break;
								}
								?></td>
								<td>
									<button style="background: red"><a id="btn" href=<?php echo e(route('xoanguoidung',$value->id)); ?> ><i class="fa fa-times"  style="color: white;"></i></a></button>
								</td>
							</tr>

                            <!-- <script>
								function myfun(id) {
								  var r = confirm("Xác nhận xóa!");
								  function handler() { alert('hello'); }
								  if (r == true) {
								  	$('#btn').onclick();
								  }
								}
							</script> -->
							<?php endforeach ?>
						</tbody>
					</table>

				</div>
			</div>
		</div>
	</div><!-- .animated -->
</div><!-- .content -->


<div class="clearfix"></div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin/layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\chiasedodung\resources\views/admin/qlnd.blade.php ENDPATH**/ ?>