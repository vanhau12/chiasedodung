<?php $__env->startSection('title'); ?>
##parent-placeholder-3c6de1b7dd91465d437ef415f94f36afc1fbc8a8##
<?php echo e($data['title']); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

<div class="hero-wrap hero-bread" style="background-image: url('img/banner/bn_2.png'); margin-top: 70px;">
      <div class="container">
        <div class="row no-gutters slider-text align-items-center justify-content-center">
          <div class="col-md-9 ftco-animate text-center">
            <p class="breadcrumbs"><span class="mr-2"><a href="<?php echo e(route('trangchu')); ?>">Trang chủ</a></span></p>
            <h1 class="mb-0 bread">Tài khoản - Thông tin tài khoản</h1>
          </div>
        </div>
      </div>
    </div>



<!-- phan thong tin tai khoan-->
<section class="product_list best_seller">
	<div class="container">
		<div class="content">
			<div class="animated fadeIn">
				<div class="row">
					<div class="col-md-2">
					</div>


					<div class="col-md-8">
						<div class="card-body card-block" >
							<form action="<?php echo e(route('tttaikhoan',Session('login'))); ?>" method="post" class="form-horizontal" enctype="multidata/form-data">
                            <?php echo csrf_field(); ?>
								<div class="row form-group">
									<div class="col col-md-12" style="text-align: center;"><label for="exampleInputName2" class="pr-1  form-control-label"><h2>Thông tin tài khoản</h2></label>
									</div>
                                    <?php if(Session::has('success')): ?>
                                    <div class="col col-md-12 text-center"><label for="exampleInputName2" class="pr-1  form-control-label"><h4 style="color: green;"><?php echo e(Session('success')); ?></h4>
                                        </label>
                                    </div>
                                    <?php endif; ?>
								</div>
								<hr/>
								<div class="row form-group">
									<div class="col col-md-3"><label for="exampleInputName2" class="pr-1  form-control-label"><b>Họ tên</b></label>
									</div>
									<div class="col-12 col-md-9"><input type="text" name="name" placeholder="Jane Doe" value="<?php echo e($data['user']->name); ?>" required="" class="form-control"><span class="help-block"></span>
									</div>
								</div>
								<hr/>
                                <div class="row form-group">
                                    <div class="col col-md-3"><label for="hf-email" class=" form-control-label"><b>Email</b></label></div>
                                    <div class="col-12 col-md-9"><input type="email" disabled id="hf-email" name="email" placeholder="Enter Email..." value="<?php echo e($data['user']->email); ?>" class="form-control"><span class="help-block"></span></div>
                                </div>
                                <hr/>
                                <div class="row form-group">
                            		<div class="col col-md-3"><label for="exampleInputName2" class="pr-1  form-control-label"><b>Số điện thoại</b></label>
                            		</div>
                            		<div class="col-12 col-md-9"><input type="text" name="phone" placeholder="Phone Number..." value="<?php echo e($data['user']->phone); ?>" required="" class="form-control"><span class="help-block"></span>
                            		</div>
                            	</div>
                            	<hr/>

                            <div class="form-actions form-group text-center"><button type="submit" class="btn btn-success btn-default" name="sub" value="admin">Cập nhật</button></div>

                        </form>
                        </div>

                    </div>

                    <div class="col-md-2">
                    </div>
                </div>
            </div><!-- .animated -->
        </div><!-- .content -->
    </div>
</section><br>
<!-- het phan thong tin tai khoan-->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('user/layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\chiasedodung\resources\views/user/thongtintaikhoan.blade.php ENDPATH**/ ?>