<?php $__env->startSection('title'); ?>
##parent-placeholder-3c6de1b7dd91465d437ef415f94f36afc1fbc8a8##
<?php echo e($data['title']); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

<div class="hero-wrap hero-bread" style="background-image: url('img/banner/bn_2.png'); margin-top: 70px;">
      <div class="container">
        <div class="row no-gutters slider-text align-items-center justify-content-center">
          <div class="col-md-9 ftco-animate text-center">
            <p class="breadcrumbs"><span class="mr-2"><a href="<?php echo e(route('trangchu')); ?>">Trang chủ</a></span></p>
            <h1 class="mb-0 bread">Tài khoản - Yêu cầu</h1>
          </div>
        </div>
      </div>
    </div>



<section class="ftco-section ftco-cart">
    <div class="container">
        <div class="row">
            <div class="col-md-12 text-center">
                <h3 style="color: green;">Lời nhắn</h3>
            </div>
            <div class="col-md-12 ftco-animate">
                <div class="cart-list">
                    <table class="table">
                        <thead class="thead-primary">
                          <tr class="text-center">
                            <th>&nbsp;</th>
                            <th>Đồ dùng</th>
                            <th>Người gửi</th>
                            <th>Lời nhắn</th>
                            <th>Trạng thái</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $data['getcontact']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                              <tr class="text-center">
                                <td class="product-remove">
                                    <a href="<?php echo e(route('tuchoi',$item->id)); ?>"><span class="ion-ios-close"></span></a>
                                    <a href="<?php echo e(route('chapnhan',$item->id)); ?>"><span class="ion-ios-checkmark"></span></a>
                                </td>

                                <td class="product-name">
                                    <b><a style="color: black;" href="<?php echo e(route('chitiet',$item->item_id)); ?>"><?php echo e($item->name); ?></a></b>
                                </td>
                                <td class="price">
                                    <span><?php echo e($item->uname); ?></span><br>
                                    <span><?php echo e($item->uphone); ?></span><br>
                                    <span><?php echo e($item->uemail); ?></span>
                                </td>
                                <td class="product-name">
                                    <span><?php echo e($item->message); ?></span><br>
                                    <p><?php echo e(date('M d, Y',$item->sent_date)); ?></p>
                                </td>

                                <td class="price">
                                    <?php if($item->status == 0): ?>
                                        <p style="color: blue;">Đang chờ</p>
                                    <?php else: ?>
                                        <?php if($item->status == 1): ?>
                                            <b style="color: green;">Chấp nhận</b>
                                        <?php else: ?>
                                            <b style="color: red;">Từ chối</b>
                                        <?php endif; ?>
                                    <?php endif; ?>
                                </td>
                            </tr><!-- END TR-->
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                    <div class="col-md-12">
                        <div class="">
                            <nav aria-label="Page navigation example">
                                <ul class="pagination justify-content-center">
                                    <?php echo e($data['getcontact']->links("pagination::bootstrap-4")); ?>

                                </ul>
                            </nav>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<section class="ftco-section ftco-cart">
    <div class="container">
        <div class="row">
            <div class="col-md-12 text-center">
                <h3 style="color: green;">Lời nhắn của tôi</h3>
            </div>
            <div class="col-md-12 ftco-animate">
                <div class="cart-list">
                    <table class="table">
                        <thead class="thead-primary">
                          <tr class="text-center">
                            <th>&nbsp;</th>
                            <th>Đồ dùng</th>
                            <th>Người nhận</th>
                            <th>Lời nhắn</th>
                            <th>Trạng thái</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $data['sentcontact']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                              <tr class="text-center">
                                <td class="product-remove">
                                    <a href="<?php echo e(route('xoaloinhan',$item->id)); ?>"><span class="ion-ios-close"></span></a>
                                </td>

                                <td class="product-name">
                                    <b><a style="color: black;" href="<?php echo e(route('chitiet',$item->item_id)); ?>"><?php echo e($item->name); ?></a></b>
                                </td>
                                <td class="price">
                                    <span><?php echo e($item->uname); ?></span><br>
                                    <span><?php echo e($item->uphone); ?></span><br>
                                    <span><?php echo e($item->uemail); ?></span>
                                </td>
                                <td class="product-name">
                                    <span><?php echo e($item->message); ?></span><br>
                                    <p><?php echo e(date('M d, Y',$item->sent_date)); ?></p>
                                </td>

                                <td class="price">
                                    <?php if($item->status == 0): ?>
                                        <p style="color: blue;">Đang chờ</p>
                                    <?php else: ?>
                                        <?php if($item->status == 1): ?>
                                            <b style="color: green;">Đã chấp nhận</b>
                                        <?php else: ?>
                                            <b style="color: red;">Đã từ chối</b>
                                        <?php endif; ?>
                                    <?php endif; ?>
                                </td>
                            </tr><!-- END TR-->
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                    <div class="col-md-12">
                        <div class="">
                            <nav aria-label="Page navigation example">
                                <ul class="pagination justify-content-center">
                                    <?php echo e($data['sentcontact']->links("pagination::bootstrap-4")); ?>

                                </ul>
                            </nav>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('user/layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\chiasedodung\resources\views/user/yeucau.blade.php ENDPATH**/ ?>