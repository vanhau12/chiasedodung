<?php $__env->startSection('title'); ?>
##parent-placeholder-3c6de1b7dd91465d437ef415f94f36afc1fbc8a8##
<?php echo e($data['title']); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

<div class="hero-wrap hero-bread" style="background-image: url('img/banner/banner-bg.jpg'); margin-top: 70px;">
      <div class="container">
        <div class="row no-gutters slider-text align-items-center justify-content-center">
          <div class="col-md-9 ftco-animate text-center">
            <p class="breadcrumbs"><span class="mr-2"><a href="<?php echo e(route('trangchu')); ?>">Trang chủ</a></span></p>
            <h1 class="mb-0 bread">Tài khoản - Đồ dùng của tôi</h1>
          </div>
        </div>
      </div>
    </div>



<section class="ftco-section ftco-cart">
    <div class="container">
        <div class="row">
            <div class="col-md-12 text-center">
                <h3 style="color: green;">Đồ dùng đang chia sẻ</h3>
            </div>
            <div class="col-md-12 ftco-animate">
                <div class="cart-list">
                    <table class="table">
                        <thead class="thead-primary">
                          <tr class="text-center">
                            <th>&nbsp;</th>
                            <th>Danh sách đồ dùng</th>
                            <th>&nbsp;</th>
                            <th>Địa điểm</th>
                            <th>Lượt xem</th>
                            <th>Lượt thích</th>
                            <th>Ngày đăng</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $data['postitems']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                              <tr class="text-center">
                                <td class="product-remove">
                                    <a href="<?php echo e(route('xoadodung',$item->id)); ?>"><span class="ion-ios-close"></span></a>
                                    <a href="<?php echo e(route('getsuadodung',$item->id)); ?>"><span class="ion-md-brush"></span></a>
                                </td>

                                <td class="image-prod">
                                    <a href="<?php echo e(route('chitiet',$item->id)); ?>"><div class="img" style="background-image:url(imagesitems/<?php echo e($item->image); ?>);"></div></a>
                                </td>

                                <td class="product-name">
                                    <h3><b><?php echo e($item->name); ?></b></h3>
                                    <p><?php echo e($item->request); ?></p>
                                </td>

                                <td class="price"><?php echo e($item->place); ?></td>
                                <td class="price"><?php echo e($item->view); ?></td>
                                
                                <td class="price"><?php echo e($item->liked); ?></td>
                                <td class="total"><?php echo e(date('M d, Y g:i a',$item->createdate)); ?></td>
                            </tr><!-- END TR-->
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                    <div class="col-md-12">
                        <div class="">
                            <nav aria-label="Page navigation example">
                                <ul class="pagination justify-content-center">
                                    <?php echo e($data['postitems']->links("pagination::bootstrap-4")); ?>

                                </ul>
                            </nav>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<section class="ftco-section ftco-cart">
    <div class="container">
        <div class="row">
            <div class="col-md-12 text-center">
                <h3 style="color: green;">Đồ dùng đang chờ duyệt</h3>
            </div>
            <div class="col-md-12 ftco-animate">
                <div class="cart-list">
                    <table class="table">
                        <thead class="thead-primary">
                          <tr class="text-center">
                            <th>&nbsp;</th>
                            <th>Danh sách đồ dùng</th>
                            <th>&nbsp;</th>
                            <th>Địa điểm</th>
                            <th>Ngày đăng</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $data['waititems']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                              <tr class="text-center">
                                <td class="product-remove"><a href="<?php echo e(route('xoadodung',$item->id)); ?>"><span class="ion-ios-close"></span></a><a href="<?php echo e(route('getsuadodung',$item->id)); ?>"><span class="ion-ios-brush"></span></a></td>

                                <td class="image-prod">
                                    <a href="<?php echo e(route('chitiet',$item->id)); ?>"><div class="img" style="background-image:url(imagesitems/<?php echo e($item->image); ?>);"></div></a>
                                    </td>

                                <td class="product-name">
                                    <h3><b><?php echo e($item->name); ?></b></h3>
                                    <p><?php echo e($item->request); ?></p>
                                </td>

                                <td class="price"><?php echo e($item->place); ?></td>

                                <td class="total"><?php echo e(date('M d, Y g:i a',$item->createdate)); ?></td>
                            </tr><!-- END TR-->
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                    <div class="col-md-12">
                        <div class="">
                            <nav aria-label="Page navigation example">
                                <ul class="pagination justify-content-center">
                                    <?php echo e($data['waititems']->links("pagination::bootstrap-4")); ?>

                                </ul>
                            </nav>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<section class="ftco-section ftco-cart">
    <div class="container">
        <div class="row">
            <div class="col-md-12 text-center">
                <h3 style="color: green;">Đồ dùng không được duyệt</h3>
            </div>
            <div class="col-md-12 ftco-animate">
                <div class="cart-list">
                    <table class="table">
                        <thead class="thead-primary">
                          <tr class="text-center">
                            <th>&nbsp;</th>
                            <th>Danh sách đồ dùng</th>
                            <th>&nbsp;</th>
                            <th>Địa điểm</th>
                            <th>Ngày đăng</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $data['passitems']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                              <tr class="text-center">
                                <td class="product-remove"><a href="<?php echo e(route('xoadodung',$item->id)); ?>"><span class="ion-ios-close"></span></a><a href="<?php echo e(route('getsuadodung',$item->id)); ?>"><span class="ion-ios-brush"></span></a></td>

                                <td class="image-prod">
                                    <a href="<?php echo e(route('chitiet',$item->id)); ?>"><div class="img" style="background-image:url(imagesitems/<?php echo e($item->image); ?>);"></div></a>
                                    </td>

                                <td class="product-name">
                                    <h3><b><?php echo e($item->name); ?></b></h3>
                                    <p><?php echo e($item->request); ?></p>
                                </td>

                                <td class="price"><?php echo e($item->place); ?></td>

                                <td class="total"><?php echo e(date('M d, Y g:i a',$item->createdate)); ?></td>
                            </tr><!-- END TR-->
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                    <div class="col-md-12">
                        <div class="">
                            <nav aria-label="Page navigation example">
                                <ul class="pagination justify-content-center">
                                    <?php echo e($data['passitems']->links("pagination::bootstrap-4")); ?>

                                </ul>
                            </nav>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('user/layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\chiasedodung\resources\views/user/dodungcuatoi.blade.php ENDPATH**/ ?>